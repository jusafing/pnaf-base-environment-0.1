/* $Id$ */
/* Snort Preprocessor Plugin Header File Template */

/* This file gets included in plugbase.h when it is integrated into the rest 
 * of the program.  
 */
#ifndef __SPP_TEMPLATE_H__
#define __SPP_TEMPLATE_H__

/* 
 * list of function prototypes to export for this preprocessor 
 */
void SetupTemplate();

#endif  /* __SPP_TEMPLATE_H__ */
